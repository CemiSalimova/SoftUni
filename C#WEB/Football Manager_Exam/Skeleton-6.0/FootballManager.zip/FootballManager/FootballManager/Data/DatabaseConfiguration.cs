﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballManager.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
              @"Server=DESKTOP-M8B0TGR\SQLEXPRESS;Database=FootballManager;Trusted_Connection=True;Integrated Security=True;";
    }
}
