﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballManager.ViewModels.PlayersViewModels
{
    public class PlayersCollectionViewModel:PlayerViewModel
    {
        public string Id { get; set; }

    }
}
