﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bakery.Constructors
{
   public interface IBakedFood:IFood
    {
    }
}
