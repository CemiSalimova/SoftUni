﻿using System;
using System.Collections.Generic;

namespace P03_FootballBetting.Data.Models
{
    public partial class Color
    {
        public Color()
        {
            TeamsPrimaryKitColor = new HashSet<Team>();
            TeamsSecondaryKitColor = new HashSet<Team>();
        }

        public int ColourId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<Team> TeamsPrimaryKitColor { get; set; }
        public virtual ICollection<Team> TeamsSecondaryKitColor { get; set; }
    }
}
