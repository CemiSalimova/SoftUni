﻿using P03_SalesDatabase.Data;
using System;

namespace P03_SalesDatabase
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var context = new SalesContext();
            //context.Database.EnsureCreated();
            //Console.WriteLine("Database created successfully.");
            

        }
    }
}
