﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
   public class Configuration
    {
        public static string ConnectionString=
            "Server= DESKTOP-M8B0TGR\\SQLEXPRESS;Database=P01_SalesDatabase;Integrated Security=True";
    }
}
