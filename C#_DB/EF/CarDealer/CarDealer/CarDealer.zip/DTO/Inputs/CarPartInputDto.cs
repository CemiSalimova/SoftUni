﻿using CarDealer.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Inputs
{
   public class CarPartInputDto
    {
        
        public int PartId { get; set; }
       
    }
}
