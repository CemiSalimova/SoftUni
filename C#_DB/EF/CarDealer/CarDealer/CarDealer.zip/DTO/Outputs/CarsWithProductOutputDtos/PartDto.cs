﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Outputs.CarsWithProductOutputDtos
{
    public class PartDto
    {
        public string Name { get; set; }
        public string Price { get; set; }
    }
}
