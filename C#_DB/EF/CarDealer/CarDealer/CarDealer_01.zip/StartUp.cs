﻿using AutoMapper;
using CarDealer.Data;
using System;
using System.IO;
using Newtonsoft.Json;
using CarDealer.DTO;
using System.Collections.Generic;
using CarDealer.Models;
using System.Linq;

namespace CarDealer
{
  public  class StartUp
    {
       private static IMapper mapper;
        static void Main(string[] args)
        {
            var context = new CarDealerContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            var suppliersFromJsonFile = File.ReadAllText("../../../Datasets/suppliers.json");
            //Console.WriteLine(suppliersFromJsonFile);
            Console.WriteLine(ImportSuppliers(context, suppliersFromJsonFile));
        }
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var suppliers = JsonConvert.DeserializeObject<IEnumerable<SuppliersInputDto>>(inputJson);
            InitializeMapper();
            var mappingSupliers = mapper.Map<IEnumerable<Supplier>>(suppliers);
            context.Suppliers.AddRange(mappingSupliers);
            context.SaveChanges();
            return $"Successfully imported {mappingSupliers.Count()}.";
        }
        private static void InitializeMapper()
        {
            var mapperConfiguration = new MapperConfiguration(config => 
                { config.AddProfile<CarDealerProfile>();
                });
            mapper = new Mapper(mapperConfiguration);
        }
    }
}
