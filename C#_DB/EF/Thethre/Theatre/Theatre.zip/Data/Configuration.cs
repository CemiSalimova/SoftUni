﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = "Server=DESKTOP-M8B0TGR\\SQLEXPRESS;Database=Theatre;Trusted_Connection=True";
    }
}
