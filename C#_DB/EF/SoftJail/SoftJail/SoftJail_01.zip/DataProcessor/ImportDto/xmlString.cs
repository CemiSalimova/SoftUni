﻿namespace SoftJail.DataProcessor.ImportDto
{
    internal class xmlString
    {
    }
}