﻿namespace SoftJail.DataProcessor
{

    using Data;
    using Newtonsoft.Json;
    using SoftJail.DataProcessor.ExportDto;
    using System;
    using System.Linq;

    public class Serializer
    {
        public static string ExportPrisonersByCells(SoftJailDbContext context, int[] ids)
        {
            var prisenors = context.Prisoners
                .ToList()
                 .Where(a => ids.Contains(a.Id))
                 .Select(pr => new
                 {
                     Id = pr.Id,
                     Name = pr.FullName,
                     CellNumber = pr.Cell.CellNumber,
                     Officers = pr.PrisonerOfficers
                     .Select(r => new
                     {
                         OfficerName = r.Officer.FullName,
                         Department = r.Officer.Department.Name
                     })
                     .OrderBy(off=>off.OfficerName)
                     .ToList(),
                     TotalOfficerSalary = Math.Round( pr.PrisonerOfficers
                     .Where(b=> ids.Contains(b.PrisonerId))
                    .Sum(a=>a.Officer.Salary),2)
                

                 }) 
                 .OrderBy(p=>p.Name)
                 .ThenBy(pp=>pp.Id)
                 .ToList();
            var result = JsonConvert.SerializeObject(prisenors,Formatting.Indented);
            return result;


        }

        public static string ExportPrisonersInbox(SoftJailDbContext context, string prisonersNames)
        {
            return "";
            // throw new NotImplementedException();
        }
    }
}